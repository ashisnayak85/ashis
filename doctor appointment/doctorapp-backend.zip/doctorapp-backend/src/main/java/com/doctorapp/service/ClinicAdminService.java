package com.doctorapp.service;

import com.doctorapp.dto.ClinicRequest;
import com.doctorapp.dto.ClinicSummaryDTO;
import com.doctorapp.dto.DoctorClinicAssociationDTO;
import com.doctorapp.entity.Clinic;
import com.doctorapp.entity.ClinicAdmin;
import com.doctorapp.entity.Doctor;
import com.doctorapp.entity.DoctorClinicAssociation;
import com.doctorapp.entity.DoctorClinicAssociation.InitiatedBy;
import com.doctorapp.entity.DoctorClinicAssociation.Status;
import com.doctorapp.exception.BusinessException;
import com.doctorapp.exception.ResourceNotFoundException;
import com.doctorapp.repository.ClinicAdminRepository;
import com.doctorapp.repository.ClinicRepository;
import com.doctorapp.repository.DoctorClinicAssociationRepository;
import com.doctorapp.repository.DoctorRepository;
import com.doctorapp.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Clinic-admin-only operations: managing the clinic(s) they own and the doctors
 * associated with them. A clinic admin creates/owns Clinic records; doctors are
 * attached via DoctorClinicAssociation, never by a direct FK on Clinic.
 */
@Service
@RequiredArgsConstructor
public class ClinicAdminService {

    private static final Logger log = LoggerFactory.getLogger(ClinicAdminService.class);

    private final ClinicAdminRepository clinicAdminRepository;
    private final ClinicRepository clinicRepository;
    private final DoctorRepository doctorRepository;
    private final DoctorClinicAssociationRepository associationRepository;
    private final UserRepository userRepository;

    public Long getClinicAdminIdForUser(Long userId) {
        return clinicAdminRepository.findByUserId(userId)
                .map(ClinicAdmin::getId)
                .orElseThrow(() -> {
                    log.warn("No clinic_admins row found for userId={} - were they registered via " +
                            "/api/auth/register/clinic-admin, or logged in with a different role's account?", userId);
                    return new ResourceNotFoundException("Clinic admin profile not found for this account");
                });
    }

    @Transactional
    public ClinicSummaryDTO createClinic(Long clinicAdminId, ClinicRequest req) {
        log.info("Creating clinic '{}' for clinicAdminId={}", req.getClinicName(), clinicAdminId);
        ClinicAdmin clinicAdmin = clinicAdminRepository.findById(clinicAdminId)
                .orElseThrow(() -> new ResourceNotFoundException("Clinic admin not found: " + clinicAdminId));

        // New clinics start unverified - an admin must verify them before they show
        // up in public search or can accept doctor associations. Mirrors Doctor.verified.
        Clinic clinic = Clinic.builder()
                .clinicAdmin(clinicAdmin)
                .clinicName(req.getClinicName())
                .address(req.getAddress())
                .latitude(req.getLatitude())
                .longitude(req.getLongitude())
                .city(req.getCity())
                .pincode(req.getPincode())
                .phone(req.getPhone())
                .verified(false)
                .active(true)
                .build();
        Clinic saved = clinicRepository.save(clinic);
        log.info("Clinic '{}' created with id={}", saved.getClinicName(), saved.getId());
        return toClinicSummary(saved);
    }

    @Transactional(readOnly = true)
    public List<ClinicSummaryDTO> getMyClinics(Long clinicAdminId) {
        return clinicRepository.findByClinicAdminId(clinicAdminId).stream()
                .map(this::toClinicSummary)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<DoctorClinicAssociationDTO> getClinicDoctors(Long clinicAdminId, Long clinicId) {
        Clinic clinic = requireOwnedClinic(clinicAdminId, clinicId);
        return associationRepository.findByClinicIdAndStatus(clinic.getId(), Status.APPROVED).stream()
                .map(this::toAssociationDTO)
                .collect(Collectors.toList());
    }

    /** All associations (any status) for every clinic this admin owns - pending requests included. */
    @Transactional(readOnly = true)
    public List<DoctorClinicAssociationDTO> getAllAssociations(Long clinicAdminId) {
        List<Long> clinicIds = clinicRepository.findByClinicAdminId(clinicAdminId).stream()
                .map(Clinic::getId).collect(Collectors.toList());
        return associationRepository.findByClinicIdIn(clinicIds).stream()
                .map(this::toAssociationDTO)
                .collect(Collectors.toList());
    }

    /** Clinic admin invites a doctor (by email) to join one of their clinics. */
    @Transactional
    public DoctorClinicAssociationDTO inviteDoctor(Long clinicAdminId, Long clinicId, String doctorEmail) {
        Clinic clinic = requireOwnedClinic(clinicAdminId, clinicId);

        Doctor doctor = doctorRepository.findByUserId(
                        userRepository.findByEmail(doctorEmail)
                                .orElseThrow(() -> new ResourceNotFoundException("No doctor account found with that email"))
                                .getId())
                .orElseThrow(() -> new ResourceNotFoundException("No doctor account found with that email"));

        DoctorClinicAssociation association = associationRepository
                .findByDoctorIdAndClinicId(doctor.getId(), clinic.getId())
                .orElse(null);

        if (association != null && association.getStatus() == Status.APPROVED) {
            throw new BusinessException("This doctor is already associated with your clinic.");
        }
        if (association != null && association.getStatus() == Status.PENDING) {
            throw new BusinessException("An invite/request with this doctor is already pending.");
        }

        if (association == null) {
            association = DoctorClinicAssociation.builder()
                    .doctor(doctor)
                    .clinic(clinic)
                    .initiatedBy(InitiatedBy.CLINIC)
                    .status(Status.PENDING)
                    .build();
        } else {
            association.setInitiatedBy(InitiatedBy.CLINIC);
            association.setStatus(Status.PENDING);
            association.setRespondedAt(null);
        }
        return toAssociationDTO(associationRepository.save(association));
    }

    /** Clinic admin approves or rejects a DOCTOR-initiated join request. */
    @Transactional
    public DoctorClinicAssociationDTO respondToJoinRequest(Long clinicAdminId, Long associationId, boolean approve) {
        DoctorClinicAssociation association = associationRepository.findById(associationId)
                .orElseThrow(() -> new ResourceNotFoundException("Association not found: " + associationId));
        requireOwnedClinic(clinicAdminId, association.getClinic().getId());

        if (association.getInitiatedBy() != InitiatedBy.DOCTOR) {
            throw new BusinessException("Only the doctor can approve an invite the clinic initiated.");
        }
        if (association.getStatus() != Status.PENDING) {
            throw new BusinessException("This request has already been responded to.");
        }
        association.setStatus(approve ? Status.APPROVED : Status.REJECTED);
        association.setRespondedAt(LocalDateTime.now());
        return toAssociationDTO(associationRepository.save(association));
    }

    /** Clinic admin removes a doctor from their clinic. */
    @Transactional
    public void removeDoctor(Long clinicAdminId, Long associationId) {
        DoctorClinicAssociation association = associationRepository.findById(associationId)
                .orElseThrow(() -> new ResourceNotFoundException("Association not found: " + associationId));
        requireOwnedClinic(clinicAdminId, association.getClinic().getId());
        association.setStatus(Status.REMOVED);
        association.setRespondedAt(LocalDateTime.now());
        associationRepository.save(association);
    }

    private Clinic requireOwnedClinic(Long clinicAdminId, Long clinicId) {
        Clinic clinic = clinicRepository.findById(clinicId)
                .orElseThrow(() -> new ResourceNotFoundException("Clinic not found: " + clinicId));
        if (!clinic.getClinicAdmin().getId().equals(clinicAdminId)) {
            throw new BusinessException("You don't manage this clinic.");
        }
        return clinic;
    }

    private ClinicSummaryDTO toClinicSummary(Clinic c) {
        long doctorCount = associationRepository.countByClinicIdAndStatus(c.getId(), Status.APPROVED);
        return ClinicSummaryDTO.builder()
                .id(c.getId())
                .clinicName(c.getClinicName())
                .address(c.getAddress())
                .city(c.getCity())
                .pincode(c.getPincode())
                .phone(c.getPhone())
                .latitude(c.getLatitude())
                .longitude(c.getLongitude())
                .verified(c.isVerified())
                .active(c.isActive())
                .doctorCount(doctorCount)
                .build();
    }

    private DoctorClinicAssociationDTO toAssociationDTO(DoctorClinicAssociation a) {
        return DoctorClinicAssociationDTO.builder()
                .id(a.getId())
                .clinicId(a.getClinic().getId())
                .clinicName(a.getClinic().getClinicName())
                .clinicAddress(a.getClinic().getAddress())
                .doctorId(a.getDoctor().getId())
                .doctorName(a.getDoctor().getName())
                .doctorQualification(a.getDoctor().getQualification())
                .initiatedBy(a.getInitiatedBy().name())
                .status(a.getStatus().name())
                .createdAt(a.getCreatedAt())
                .respondedAt(a.getRespondedAt())
                .build();
    }
}
